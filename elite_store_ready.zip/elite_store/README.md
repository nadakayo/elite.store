# Elite Store — free static storefront

A responsive Black & Gold fashion storefront built with plain HTML, CSS and JavaScript.

## Included
- Product grid with Clothing / Shoes / Accessories filters
- Add-to-cart, quantity controls and cart total
- Order form that prepares an order message for WhatsApp
- Responsive mobile layout
- No build step, framework, paid theme or database required

## Before publishing
1. Open `index.html` in a text editor.
2. Find `const STORE_WHATSAPP = "212600000000";`
3. Replace it with your WhatsApp number in international format, digits only. Example Morocco: `2126XXXXXXXX` (do not include `+` or spaces).
4. Edit the sample product names, prices and image URLs in the `products` array.
5. The products and prices are demo content. Confirm stock, sizing, delivery terms and prices before accepting orders.

## Free hosting with Cloudflare Pages
1. Create a GitHub account at https://github.com/ and a Cloudflare account at https://dash.cloudflare.com/.
2. Create a new GitHub repository, e.g. `elite-store`.
3. Upload `index.html` to the repository root (and this README if you want).
4. In Cloudflare, open **Workers & Pages** → **Create** → **Pages** → **Connect to Git**.
5. Select your GitHub repository.
6. For a plain HTML site, choose no framework. Leave build command empty and set build output directory to `/` (or `.` if the interface requests a relative directory).
7. Deploy. Cloudflare will provide a free `*.pages.dev` address.

## Important limitations
- This is a static demo storefront. It does not process card payments, manage inventory, or save orders to a database.
- WhatsApp checkout requires the store owner's real WhatsApp number and customers must send the prepared message.
- Image URLs use Unsplash and Google Fonts, so those assets need an internet connection.
- A free `pages.dev` address is included; a custom domain usually costs money.
- If you are under 18, ask a parent/guardian to help create accounts and handle payment, legal and customer-data responsibilities.
